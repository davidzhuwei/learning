package com.example.springCloudApp.springCloudApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudAppApplication.class, args);
	}
}
