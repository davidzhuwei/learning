package com.example.spingCloudConfServer.spingCloudConfServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpingCloudConfServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpingCloudConfServerApplication.class, args);
	}
}
