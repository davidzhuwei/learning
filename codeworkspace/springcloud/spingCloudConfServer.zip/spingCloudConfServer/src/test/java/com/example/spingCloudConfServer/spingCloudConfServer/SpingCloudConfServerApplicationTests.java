package com.example.spingCloudConfServer.spingCloudConfServer;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpingCloudConfServerApplicationTests {

	@Test
	public void contextLoads() {
	}

}
